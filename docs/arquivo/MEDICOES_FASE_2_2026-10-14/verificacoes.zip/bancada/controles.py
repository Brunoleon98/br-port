import subprocess,sys,json
from executar import rodar,pasta
subprocess.run([sys.executable,'-X','utf8',str(pasta/'mutantes.py')],check=True)
for nome,flag in [('quebra-forcada',[]),('quebra-apos-meta',['--apos-meta'])]:
    rodar(nome,str(pasta/'forcar_quebra.gd'),[1,20260825,pasta/(nome+'.json'),56,'--sem-save',*flag])
    d=json.loads((pasta/(nome+'.json')).read_text(encoding='utf-8'))
    for g in d['resultados']:
        r=g['resumo']
        assert r['entraram']==1 and r['travadas']==0
        if not flag:
            assert r['quebras_antes_meta']==1 and r['metas']==0 and r['censuradas']==0
        elif g['perfil']=='Descuidado':
            assert r['censuradas']==1 and r['metas']==0
        else:
            assert r['metas']==1 and r['quebras_apos_meta']==1 and r['censuradas']==0
    print(nome+': desfechos do motor conferidos',flush=True)
