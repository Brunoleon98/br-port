from pathlib import Path
import os, subprocess, re, sys, time, json

repo = Path.cwd()
pasta = repo / '.evidencias/108'
pasta.mkdir(parents=True, exist_ok=True)
env = os.environ.copy()
env['APPDATA'] = env['LOCALAPPDATA'] = str(pasta / 'perfil')
godot = r'C:\Users\bruno\Downloads\Godot_v4.6.3-stable_win64.exe\Godot_v4.6.3-stable_win64_console.exe'

def rodar(nome, script, args=(), marcador='FASE 2 MEDIDA'):
    inicio = time.monotonic()
    with (pasta / (nome + '.log')).open('w', encoding='utf-8') as saida:
        r = subprocess.run([godot, '--headless', '--path', 'brport_vs', '--script', script,
                            '--', *map(str,args)], env=env, stdout=saida,
                            stderr=subprocess.STDOUT, timeout=1200)
    t = (pasta / (nome + '.log')).read_text(encoding='utf-8')
    assert r.returncode == 0 and marcador in t, (nome, r.returncode, t[-2500:])
    assert not re.search(r'SCRIPT ERROR|at: push_error \(|possível travamento', t), nome
    print(nome, round(time.monotonic()-inicio,2), 's', flush=True)
    return t

if __name__ == '__main__':
    nome = sys.argv[1]
    n = int(sys.argv[2]) if len(sys.argv)>2 else 600
    janela = int(sys.argv[3]) if len(sys.argv)>3 else 365
    args = [n,20260825,pasta/(nome+'.json'),janela]
    if '--com-save' not in sys.argv:
        args.append('--sem-save')
    t = rodar(nome, 'res://tools/medir_fase_2.gd', args)
    print(t[t.index('Ótimo:'):], flush=True)
