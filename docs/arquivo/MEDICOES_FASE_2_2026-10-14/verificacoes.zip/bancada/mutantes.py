from pathlib import Path
import subprocess, sys, json
from executar import pasta
fonte=Path('brport_vs/tools/leitura_fase_2.gd')
original=fonte.read_bytes()
resultados=[]
try:
    for nome,antigo,novo in [
        ('censura-conta-conquista',b'elif not meta:',b'else:'),
        ('sem-meta-vira-dia-zero',b'"p10": null, "p50": null, "p90": null',b'"p10": 0, "p50": 0, "p90": 0')]:
        assert original.count(antigo)==1
        fonte.write_bytes(original.replace(antigo,novo))
        subprocess.run([sys.executable,'-X','utf8',str(pasta/'t23.py'),nome,'--reprova'],check=True)
        fonte.write_bytes(original)
        subprocess.run([sys.executable,'-X','utf8',str(pasta/'t23.py'),'restaurado-'+nome],check=True)
        resultados.append({'defeito':nome,'reprovou':True,'restaurado_passou':True})
finally:
    fonte.write_bytes(original)
(pasta/'mutantes.json').write_text(json.dumps(resultados,ensure_ascii=False,indent=2),encoding='utf-8')
