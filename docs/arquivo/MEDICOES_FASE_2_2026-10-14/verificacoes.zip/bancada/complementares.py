from pathlib import Path
import subprocess, sys, json, copy
from executar import rodar, pasta, env, godot

def py(args, nome):
    with (pasta/(nome+'.log')).open('w',encoding='utf-8') as f:
        p=subprocess.run([sys.executable,'-X','utf8',*map(str,args)],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
    t=(pasta/(nome+'.log')).read_text(encoding='utf-8')
    assert p.returncode==0,(nome,t[-3000:])
    print(nome+': '+t[-250:].strip(),flush=True)

def comparar(a,b):
    if isinstance(a,dict):
        assert isinstance(b,dict) and a.keys()==b.keys()
        return sum(comparar(a[k],b[k]) for k in a)
    if isinstance(a,list):
        assert isinstance(b,list) and len(a)==len(b)
        return sum(comparar(v,w) for v,w in zip(a,b))
    assert a==b,(a,b)
    return 1

py(['tools/importar_para_ci.py','brport_vs',godot],'importacao')
for nome,flag in [('amostra-sem-save',['--sem-save']),('amostra-com-save',[])]:
    rodar(nome,'res://tools/medir_fase_2.gd',[3,20260825,pasta/(nome+'.json'),56,*flag])
a=json.loads((pasta/'amostra-sem-save.json').read_text(encoding='utf-8'))
b=json.loads((pasta/'amostra-com-save.json').read_text(encoding='utf-8'))
n=comparar(a,b)
c=copy.deepcopy(b); c['resultados'][0]['partidas'][0]['caixa_final']+=1
try: comparar(a,c)
except AssertionError: pass
else: raise AssertionError('Controle de paridade não reprovou')
paridade={'autosave':{'partidas_por_perfil':3,'janela':56,'folhas_iguais':n,'controle_alterado_reprovou':True}}
print('AUTOSAVE: paridade em',n,'folhas',flush=True)
rodar('fase-1','res://tools/simular_balanceamento.gd',[600,20260825,pasta/'fase-1.json','--sem-save'],'Medição despejada em')
a=json.loads((pasta.parent/'106/depois.json').read_text(encoding='utf-8'))
b=json.loads((pasta/'fase-1.json').read_text(encoding='utf-8'))
paridade['fase_1']={'partidas_por_perfil':600,'semente':20260825,'folhas_iguais':comparar(a,b)}
(pasta/'paridades.json').write_text(json.dumps(paridade,ensure_ascii=False,indent=2),encoding='utf-8')
print('FASE 1: paridade',paridade['fase_1'],flush=True)
rodar('constantes','res://tools/despejar_constantes.gd',[pasta/'constantes.json'],'CONSTANTES')
py(['tools/gerar_tabela_numeros.py','--contra-godot',pasta/'constantes.json'],'tabela-gerar')
py(['tools/gerar_tabela_numeros.py','--conferir','--contra-godot',pasta/'constantes.json'],'tabela-conferir')
py(['tools/projetar_parcelas.py','--medicao',pasta/'fase-1.json','--constantes',pasta/'constantes.json'],'projetor')
py([pasta/'validar.py','suites'],'seis-suites')
