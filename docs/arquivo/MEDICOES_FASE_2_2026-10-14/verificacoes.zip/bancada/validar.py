from pathlib import Path
import os, re, subprocess, sys

pasta = Path(__file__).resolve().parent
repo = pasta.parents[1]
godot = r'C:\Users\bruno\Downloads\Godot_v4.6.3-stable_win64.exe\Godot_v4.6.3-stable_win64_console.exe'
env = os.environ.copy()
env['APPDATA'] = env['LOCALAPPDATA'] = str(pasta / 'perfil')
(pasta / 'perfil').mkdir(exist_ok=True)

def executar(nome, args, marcador, retorno=0):
    log = pasta / (nome + '.log')
    with log.open('w', encoding='utf-8') as saida:
        p = subprocess.run(args, cwd=repo, env=env, stdout=saida,
                           stderr=subprocess.STDOUT, timeout=1200)
    t = log.read_text(encoding='utf-8', errors='replace')
    assert p.returncode == retorno, (nome, p.returncode, t[-3000:])
    assert marcador in t, (nome, t[-3000:])
    assert not re.search(r'SCRIPT ERROR|at: push_error \(', t), (nome, t[-3000:])
    print(nome + ': ' + marcador, flush=True)

if sys.argv[1] == 'suites':
    executar('sentinela-antes', [sys.executable, '-X', 'utf8',
             'tools/sentinela_do_jogador.py', 'plantar', 'brport_vs'], 'Sentinela')
    for nome, marcador in [('run_tests', 'TODOS OS TESTES PASSARAM'),
            ('teste_design', 'DESIGN OK'), ('teste_audio', 'AUDIO OK'),
            ('teste_fumaca', 'FUMACA OK'), ('teste_registro', 'REGISTRO OK'),
            ('asset_validator', 'ASSET OK')]:
        script = ('scripts/validation/' if nome == 'asset_validator' else 'tests/') + nome + '.gd'
        executar(nome, [godot, '--headless', '--path', 'brport_vs', '--script', 'res://' + script], marcador)
    executar('sentinela-depois', [sys.executable, '-X', 'utf8',
             'tools/sentinela_do_jogador.py', 'conferir', 'brport_vs'], 'SENTINELA')
elif sys.argv[1] == 'fumaca':
    executar(sys.argv[2], [godot, '--headless', '--path', 'brport_vs', '--script',
             'res://tests/teste_fumaca.gd'], sys.argv[3], int(sys.argv[4]))
elif sys.argv[1] == 'export':
    (repo / 'build/web107').mkdir(parents=True, exist_ok=True)
    # Os templates ficam só no perfil isolado desta tarefa.
    executar('export', [godot, '--headless', '--path', 'brport_vs', '--export-release',
             'Web', '../build/web107/index.html'], 'savepack', 0)

