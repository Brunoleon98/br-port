extends "res://tests/run_tests.gd"

func _run() -> void:
	_t23_medicao_fase_2()
	_check("T23 completo", _t23_completo)
	print("T23 OK" if _fails == 0 else "T23 REPROVOU")
	quit(_fails)
