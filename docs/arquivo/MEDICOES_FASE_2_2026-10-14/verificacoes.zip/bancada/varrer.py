from pathlib import Path
import os, json, subprocess, hashlib
from executar import rodar, pasta

fonte = Path('brport_vs/autoload/GameState.gd')
original = fonte.read_bytes()
assert original == subprocess.check_output(['git','show','HEAD:brport_vs/autoload/GameState.gd'])
(pasta/'GameState-pristino.gd').write_bytes(original)

def trocar(s, a, b):
    assert s.count(a) == 1, a
    return s.replace(a,b)

def variante(param):
    s = original
    if 'custos' in param:
        for velho, ordem, valor in [(260000,2,param['custos'][0]),(80000,5,param['custos'][1]),(80000,6,param['custos'][2])]:
            s = trocar(s, f'"custo": {velho}, "ordem": {ordem}'.encode(), f'"custo": {valor}, "ordem": {ordem}'.encode())
    cab, sep, fase = s.partition(b'"semanas": null,')
    assert sep and b'"semanas": null,' not in fase
    for campo, velho in [('meta',80.0),('piso',40.0),('inicio',65.0)]:
        chave = {'meta':b'"meta": {"reputacao": ', 'piso':b'"piso_cargueiro": ', 'inicio':b'"reputacao_inicial": '}[campo]
        if campo in param:
            fase = trocar(fase, chave+str(velho).encode(), chave+str(float(param[campo])).encode())
    if 'dias' in param:
        for id, velho in [('pier_3',3),('trelica',2),('escritorio',2)]:
            a = f'"{id}": {{"semana": 1, "quitadas": 0, "dias_de_obra": {velho}}}'.encode()
            fase = trocar(fase,a,a.replace(str(velho).encode()+b'}',str(param['dias'][id]).encode()+b'}'))
    return cab+sep+fase

cenarios = [
    ('precos-metade', {'custos':[130000,40000,40000]}),
    ('precos-mais-50', {'custos':[390000,120000,120000]}),
    ('meta-70', {'meta':70}), ('meta-90', {'meta':90}),
    ('piso-20', {'piso':20}), ('piso-60', {'piso':60}),
    ('inicio-55', {'inicio':55}), ('inicio-75', {'inicio':75}),
    ('obras-curtas', {'dias':{'pier_3':2,'trelica':1,'escritorio':1}}),
    ('obras-longas', {'dias':{'pier_3':5,'trelica':4,'escritorio':4}}),
]
resumos = []
try:
    for nome, param in cenarios:
        assert fonte.read_bytes() == original
        novo = variante(param)
        tmp = fonte.with_suffix('.gd.tmp')
        tmp.write_bytes(novo)
        os.chmod(tmp, fonte.stat().st_mode)
        os.replace(tmp, fonte)
        try:
            rodar(nome,'res://tools/medir_fase_2.gd',[600,20260825,pasta/(nome+'.json'),365,'--sem-save'])
            dados = json.loads((pasta/(nome+'.json')).read_text(encoding='utf-8'))
            if 'custos' in param:
                assert [dados['custos'][k] for k in ['pier_3','escritorio','trelica']] == param['custos']
            for campo, chave in [('piso','piso_cargueiro'),('inicio','reputacao_inicial')]:
                if campo in param: assert dados['fase_2'][chave] == param[campo]
            if 'meta' in param: assert dados['fase_2']['meta']['reputacao'] == param['meta']
            if 'dias' in param:
                for k,v in param['dias'].items(): assert dados['fase_2']['reparos'][k]['dias_de_obra'] == v
            resumo = {'cenario':nome,'parametros':param,'sha256_fonte':hashlib.sha256(novo).hexdigest(),
                'perfis':[{ 'perfil':g['perfil'], **g['resumo']} for g in dados['resultados']]}
            resumos.append(resumo)
            print(json.dumps({'cenario':nome, 'metas':[r['metas'] for r in resumo['perfis']],
                'dias_p50':[r['dias_ate_meta']['p50'] for r in resumo['perfis']]},ensure_ascii=False),flush=True)
        finally:
            fonte.write_bytes(original)
        (pasta/'varredura.json').write_text(json.dumps(resumos,ensure_ascii=False,indent=2),encoding='utf-8')
finally:
    fonte.write_bytes(original)
assert fonte.read_bytes() == original
print('VARREDURA RESTAURADA',hashlib.sha256(original).hexdigest(),flush=True)
