from pathlib import Path
import subprocess, os, re, sys
pasta=Path(__file__).resolve().parent
env=os.environ.copy()
env['APPDATA']=env['LOCALAPPDATA']=str(pasta/'perfil-t23')
godot=r'C:\Users\bruno\Downloads\Godot_v4.6.3-stable_win64.exe\Godot_v4.6.3-stable_win64_console.exe'
nome=sys.argv[1] if len(sys.argv)>1 else 't23-base'
with (pasta/(nome+'.log')).open('w',encoding='utf-8') as saida:
    r=subprocess.run([godot,'--headless','--path','brport_vs','--script',str(pasta/'t23.gd')],
        env=env,stdout=saida,stderr=subprocess.STDOUT,timeout=60)
t=(pasta/(nome+'.log')).read_text(encoding='utf-8')
assert not re.search(r'SCRIPT ERROR|at: push_error \(',t),t
if '--reprova' in sys.argv:
    assert r.returncode != 0 and 'T23 REPROVOU' in t,t
else:
    assert r.returncode == 0 and 'T23 OK' in t,t
print(nome+': '+('reprovou como esperado' if '--reprova' in sys.argv else 'passou'))
