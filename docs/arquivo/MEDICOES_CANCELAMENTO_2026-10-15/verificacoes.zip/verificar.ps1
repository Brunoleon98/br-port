$ErrorActionPreference = 'Stop'
$pythonSessao = 'C:\Users\bruno\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$godotSessao = 'C:\Users\bruno\Downloads\Godot_v4.6.3-stable_win64.exe\Godot_v4.6.3-stable_win64_console.exe'
$evidenciaSessao = Join-Path (Get-Location) '.evidencias\medir-cancelamento'
$env:APPDATA = Join-Path $env:TEMP 'br-port-cancelamento-verificacao'
$env:PYTHONUTF8 = '1'
New-Item -ItemType Directory -Force -Path $env:APPDATA | Out-Null
function Rodar-Godot([string]$nome, [string]$marcador, [string[]]$argumentos) {
 $log = Join-Path $evidenciaSessao ($nome + '.log')
 & $godotSessao @argumentos *> $log
 $codigo = $LASTEXITCODE
 $texto = Get-Content -Raw -LiteralPath $log
 if ($codigo -ne 0 -or -not $texto.Contains($marcador) -or $texto -match 'SCRIPT ERROR|at: push_error \(') { Get-Content $log -Tail 30; throw ($nome + ' reprovado') }
 Write-Output ($nome + ': OK')
}
& $pythonSessao tools/testar_bancada_cancelamento.py --godot $godotSessao --saida (Join-Path $evidenciaSessao 'controles')
if ($LASTEXITCODE -ne 0) { throw 'Controles reprovados' }
foreach ($modo in @('sem-save','com-save')) {
 $argumentos = @('tools/medir_cancelamento.py', '--godot', $godotSessao, '--saida', (Join-Path $evidenciaSessao $modo), '--cenario', 'candidato-taxa', '--partidas', '2', '--janela', '60')
 if ($modo -eq 'com-save') { $argumentos += '--com-save' }
 & $pythonSessao @argumentos
 if ($LASTEXITCODE -ne 0) { throw 'Paridade não rodou' }
}
& $pythonSessao tools/sentinela_do_jogador.py plantar brport_vs
if ($LASTEXITCODE -ne 0) { throw 'Sentinela não preparada' }
Rodar-Godot 'importacao' 'Godot Engine' @('--headless','--path','brport_vs','--editor','--import')
Rodar-Godot 'constantes' 'CONSTANTES OK' @('--headless','--path','brport_vs','--script','res://tools/despejar_constantes.gd','--',(Join-Path $evidenciaSessao 'constantes.json'))
Rodar-Godot 'fase-1' '=== Leitura ===' @('--headless','--path','brport_vs','--script','res://tools/simular_balanceamento.gd','--','600','20260825',(Join-Path $evidenciaSessao 'fase-1.json'),'--sem-save')
& $pythonSessao tools/gerar_tabela_numeros.py --conferir --contra-godot (Join-Path $evidenciaSessao 'constantes.json') *> (Join-Path $evidenciaSessao 'tabela.log')
if ($LASTEXITCODE -ne 0) { throw 'Tabela reprovada' }
& $pythonSessao tools/projetar_parcelas.py --medicao (Join-Path $evidenciaSessao 'fase-1.json') --constantes (Join-Path $evidenciaSessao 'constantes.json') *> (Join-Path $evidenciaSessao 'projetor.log')
if ($LASTEXITCODE -ne 0) { throw 'Projetor reprovado' }
$suites = [ordered]@{'tests/run_tests.gd'='TODOS OS TESTES PASSARAM'; 'tests/teste_design.gd'='DESIGN OK'; 'tests/teste_audio.gd'='AUDIO OK'; 'tests/teste_fumaca.gd'='FUMACA OK'; 'tests/teste_registro.gd'='REGISTRO OK'; 'scripts/validation/asset_validator.gd'='ASSET OK'}
foreach ($suite in $suites.GetEnumerator()) {
 Rodar-Godot ([IO.Path]::GetFileNameWithoutExtension($suite.Key)) $suite.Value @('--headless','--path','brport_vs','--script',('res://' + $suite.Key))
}
& $pythonSessao tools/sentinela_do_jogador.py conferir brport_vs *> (Join-Path $evidenciaSessao 'sentinela.log')
if ($LASTEXITCODE -ne 0) { throw 'Sentinela alterada' }
Write-Output 'VERIFICACAO CANCELAMENTO OK'
