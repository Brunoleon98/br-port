from pathlib import Path
import hashlib, json, re, shutil, subprocess, zipfile

raiz = Path.cwd()
e = raiz / '.evidencias/medir-cancelamento'
a = raiz / 'docs/arquivo/MEDICOES_CANCELAMENTO_2026-10-15'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def zipar(nome, arquivos):
    manifesto = {}
    with zipfile.ZipFile(a/nome, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for origem, destino in arquivos:
            b = origem.read_bytes()
            assert destino not in manifesto
            z.writestr(destino, b)
            manifesto[destino] = {'bytes':len(b), 'sha256':sha(b)}
    with zipfile.ZipFile(a/nome) as z:
        assert set(z.namelist()) == set(manifesto)
        for n, m in manifesto.items():
            b = z.read(n)
            assert len(b) == m['bytes'] and sha(b) == m['sha256']
    return manifesto

resumo = json.loads((e/'completa/resumo.json').read_text(encoding='utf-8'))
shutil.copyfile(e/'completa/resumo.json', a/'resumo.json')
sem = json.loads((e/'sem-save/candidato-taxa.json').read_text(encoding='utf-8'))
com = json.loads((e/'com-save/candidato-taxa.json').read_text(encoding='utf-8'))
assert sem == com
quantidade_eventos = sum(len(p['cancelamentos']) for g in sem['resultados'] for p in g['partidas'])
suites = {'run_tests':'TODOS OS TESTES PASSARAM', 'teste_design':'DESIGN OK', 'teste_audio':'AUDIO OK', 'teste_fumaca':'FUMACA OK', 'teste_registro':'REGISTRO OK', 'asset_validator':'ASSET OK'}
for nome, marcador in suites.items():
    log = (e/f'{nome}.log').read_text(encoding='utf-8')
    assert marcador in log and not re.search(r'SCRIPT ERROR|at: push_error \(', log), nome
assert 'SENTINELA INTACTA' in (e/'sentinela.log').read_text(encoding='utf-8')
assert 'TABELA OK' in (e/'tabela.log').read_text(encoding='utf-8')
assert 'calibrado' in (e/'projetor.log').read_text(encoding='utf-8')
importacao = (e/'importacao-seriada.log').read_text(encoding='utf-8')
assert 'SCRIPT ERROR' not in importacao and 'at: push_error (' not in importacao
assert 'DOCS OK' in (e/'docs.log').read_text(encoding='utf-8')
mutantes = json.loads((e/'controles/mutantes.json').read_text(encoding='utf-8'))
assert len(mutantes) == 4
for n in mutantes:
    log = (e/'controles'/f'{n}.log').read_text(encoding='utf-8')
    assert 'FALHOU ' in log and 'SCRIPT ERROR' not in log and 'BANCADA CANCELAMENTO OK' not in log
    assert 'BANCADA CANCELAMENTO OK' in (e/'controles'/f'restaurado-{n}.log').read_text(encoding='utf-8')
fontes = ['brport_vs/autoload/GameState.gd','brport_vs/tools/medir_fase_2.gd','brport_vs/tools/simular_balanceamento.gd']
subprocess.run(['git','diff','--exit-code','origin/main','--',*fontes], check=True, stdout=subprocess.DEVNULL)
fontes += [str(p.relative_to(raiz)).replace('\\','/') for p in (raiz/'brport_vs/tools').glob('*cancelamento*.gd')]
fontes += [str(p.relative_to(raiz)).replace('\\','/') for p in (raiz/'tools').glob('*cancelamento*.py')]
verificacao = {'godot':'4.6.3', 'base_main':'82a9df0', 'partidas_principais':31200,
    'paridade_main_campos':resumo['paridade_main_campos'], 'paridade_autosave_partidas':8,
    'paridade_autosave_eventos':quantidade_eventos, 'paridade_autosave_integral':True,
    'mutantes_motor':mutantes, 'mutantes_conferidor':resumo['controles_do_conferidor'],
    'suites':suites, 'sentinela':'cinco arquivos intactos no perfil isolado',
    'game_state_e_simuladores_originais_intactos':True,
    'importacao_sem_avisos':False,
    'importacao':'Safe save failed persistiu no helper seriado do CI e na repetição verbose. Godot retornou zero; arquivo e causa não identificados. Importação não considerada limpa, embora suítes e medições passem.',
    'sha256_fontes':{n:sha((raiz/n).read_bytes()) for n in fontes}}
(a/'verificacao.json').write_text(json.dumps(verificacao,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
dados = [(p, 'principal/'+p.name) for p in sorted((e/'completa').glob('*.json')) if p.name != 'resumo.json']
dados += [(e/modo/'candidato-taxa.json',f'{modo}/candidato-taxa.json') for modo in ['sem-save','com-save']]
dados += [(e/'constantes.json','constantes.json'), (e/'fase-1.json','fase-1.json')]
manifesto = {'partidas.zip': zipar('partidas.zip', dados)}
logs = [(p, str(p.relative_to(e)).replace('\\','/')) for p in sorted(e.rglob('*.log')) if '/perfil/' not in str(p).replace('\\','/')]
logs += [(e/'controles/mutantes.json','controles/mutantes.json'), (e/'verificar.ps1','verificar.ps1'),(e/'empacotar.py','empacotar.py')]
manifesto['verificacoes.zip'] = zipar('verificacoes.zip', logs)
(a/'manifesto.json').write_text(json.dumps(manifesto,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('PACOTE CANCELAMENTO OK', {n:(a/n).stat().st_size for n in manifesto})
